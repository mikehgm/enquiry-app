/**
 * Convierte una cadena tipo 'YYYY-MM-DD' a un objeto Date sin modificar la zona horaria.
 * @param dateString Formato esperado: '2025-05-20'
 * @returns Date con la fecha exacta local
 */
export function parseLocalDate(dateString: string): Date {
  const [year, month, day] = dateString.split('-').map(Number);
  return new Date(year, month - 1, day);
}
